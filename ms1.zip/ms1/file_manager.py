# file_manager.py
import os
from tkinter import messagebox, Toplevel, Scrollbar, VERTICAL, RIGHT, LEFT, Y, BOTH
from tkinter import ttk


class FileManager:
    def __init__(self, score_file="minesweeper_scores.txt", saves_dir="saves"):
        self.score_file = score_file
        self.saves_dir = saves_dir
        os.makedirs(self.saves_dir, exist_ok=True)
        self.slot_files = [os.path.join(self.saves_dir, f"slot{i}.txt") for i in range(1, 4)]

    def save_score(self, name, elapsed, rows, cols, mines, result, seed=None):
        """
        Save a score line.
        Format: name,elapsed,rows,cols,mines,result,seed
        seed optional -> written as '?' if None.
        """
        seed_val = "?" if seed is None else str(seed)
        with open(self.score_file, "a") as f:
            f.write(f"{name},{elapsed},{rows},{cols},{mines},{result},{seed_val}\n")

    def load_scores(self):
        """
        Load all scores as dicts:
        {name, elapsed, rows, cols, mines, result, seed}
        Chronological order preserved (oldest -> newest).
        """
        if not os.path.exists(self.score_file):
            return []

        with open(self.score_file, "r") as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]

        scores = []
        for line in lines:
            parts = [p.strip() for p in line.split(",")]
            if len(parts) < 5:
                continue
            name = parts[0]
            elapsed = parts[1] if len(parts) > 1 else "?"
            rows = parts[2] if len(parts) > 2 else "?"
            cols = parts[3] if len(parts) > 3 else "?"
            mines = parts[4] if len(parts) > 4 else "?"
            result = parts[5].lower() if len(parts) > 5 else "?"
            seed = parts[6] if len(parts) > 6 else "?"
            scores.append({
                "name": name,
                "elapsed": elapsed,
                "rows": rows,
                "cols": cols,
                "mines": mines,
                "result": result,
                "seed": seed
            })
        return scores

    def show_scores(self):
        """
        Two explicit tabs: 'Wins' and 'Losses'.
        Each tab lists one row per player:
          - Wins tab: most recent WIN for each player (if any)
          - Losses tab: most recent LOSS for each player (if any)
        Single-click a parent row to expand/collapse an inline dropdown showing all that player's games,
        each child includes seed and other meta.
        """
        scores = self.load_scores()
        if not scores:
            messagebox.showinfo("Leaderboard", "No scores yet, be the first loser.")
            return

        # Total games per player (meta)
        games_count = {}
        for s in scores:
            games_count[s["name"]] = games_count.get(s["name"], 0) + 1

        # Build latest win and latest loss maps (scan oldest->newest so newer entries overwrite)
        latest_win_by_name = {}
        latest_loss_by_name = {}
        for s in scores:
            if s["result"] == "win":
                latest_win_by_name[s["name"]] = s
            elif s["result"] == "lose":
                latest_loss_by_name[s["name"]] = s

        wins = list(latest_win_by_name.values())
        losses = list(latest_loss_by_name.values())

        def timekey(e):
            t = e["elapsed"]
            return int(t) if t.isdigit() else 999999

        wins.sort(key=timekey)
        losses.sort(key=timekey)

        # Styling and window
        style = ttk.Style()
        style_name = "Table.Treeview"
        style.configure(style_name, rowheight=20, bordercolor="#C0C0C0", borderwidth=1, relief="solid", background="#FFFFFF", fieldbackground="#FFFFFF")
        style.configure(style_name + ".Heading", font=("Arial", 10, "bold"))
        style.map(style_name, background=[("selected", "#d9eaff")])

        win = Toplevel()
        win.title("Leaderboard")
        win.geometry("760x420")
        win.minsize(520, 320)

        notebook = ttk.Notebook(win)
        notebook.pack(fill=BOTH, expand=True, padx=6, pady=6)

        columns = ("player", "time", "difficulty", "games")

        def create_tab(tab_title, data_list, tag_prefix):
            frame = ttk.Frame(notebook)
            notebook.add(frame, text=tab_title)

            tree = ttk.Treeview(frame, columns=columns, show="headings", style=style_name)
            tree.heading("player", text="Player")
            tree.heading("time", text="Time (s)")
            tree.heading("difficulty", text="Difficulty [rowsxcols,mines]")
            tree.heading("games", text="#Games")

            tree.column("player", width=220, anchor="w")
            tree.column("time", width=80, anchor="center")
            tree.column("difficulty", width=320, anchor="center")
            tree.column("games", width=80, anchor="center")

            vsb = Scrollbar(frame, orient=VERTICAL, command=tree.yview)
            tree.configure(yscrollcommand=vsb.set)
            vsb.pack(side=RIGHT, fill=Y)
            tree.pack(side=LEFT, fill=BOTH, expand=True)

            # Insert parent rows for each player (their most recent in this tab)
            for idx, s in enumerate(data_list):
                name = s["name"]
                t = s["elapsed"]
                diff_label = f"[{s['rows']}x{s['cols']},{s['mines']}]"
                gcount = games_count.get(name, 1)
                parent_iid = f"{tag_prefix}_parent_{idx}_{name}"
                tree.insert("", "end", iid=parent_iid, values=(name, t, diff_label, gcount))
                tree.item(parent_iid, open=False)

            # Insert children (full history) under each parent
            for parent in tree.get_children():
                player = tree.item(parent, "values")[0]
                history = [h for h in scores if h["name"] == player]
                if not history:
                    continue
                # header child for readability
                header_iid = f"{parent}_hdr"
                tree.insert(parent, "end", iid=header_iid, values=(f"   #   Result   Time(s)   Difficulty   Seed", "", "", ""))
                for i, h in enumerate(history, start=1):
                    seed_disp = h.get("seed", "?")
                    diff = f"[{h['rows']}x{h['cols']},{h['mines']}]"
                    child_text = f"   {i}.   {h['result']}   {h['elapsed']}   {diff}   {seed_disp}"
                    child_iid = f"{parent}_child_{i}"
                    tree.insert(parent, "end", iid=child_iid, values=(child_text, "", "", ""))

            # alternating background for parent rows
            parents = tree.get_children()
            for i, pid in enumerate(parents):
                tree.item(pid, tags=("even",) if i % 2 == 0 else ("odd",))
            tree.tag_configure("even", background="#FFFFFF")
            tree.tag_configure("odd", background="#F6F6F6")

            tree.configure(borderwidth=1, relief="solid")

            # Single-click toggles expand/collapse for parent rows.
            def on_click(event):
                row = tree.identify_row(event.y)
                if not row:
                    return
                # If click is on child, toggle parent instead
                if tree.parent(row):
                    parent_id = tree.parent(row)
                else:
                    parent_id = row
                if tree.parent(parent_id) == "":
                    tree.item(parent_id, open=not tree.item(parent_id, "open"))

            tree.bind("<ButtonRelease-1>", on_click)
            return tree

        create_tab("Wins", wins, "wins")
        create_tab("Losses", losses, "losses")

        win.update_idletasks()
        return win

    # --- slot/save utilities (unchanged) ---
    def clear_scores(self):
        if os.path.exists(self.score_file):
            if messagebox.askyesno("Confirm", "Clear leaderboard? Cannot be undone."):
                os.remove(self.score_file)
                messagebox.showinfo("Done", "Leaderboard cleared.")
        else:
            messagebox.showinfo("Info", "Leaderboard already empty.")

    def slot_exists(self, slot):
        return os.path.exists(self.slot_files[slot - 1])

    def delete_slot_file(self, slot):
        path = self.slot_files[slot - 1]
        if os.path.exists(path):
            os.remove(path)

    def delete_all_slots(self):
        for path in self.slot_files:
            if os.path.exists(path):
                os.remove(path)

    def write_slot(self, slot, board_obj, elapsed):
        path = self.slot_files[slot - 1]
        seed_val = board_obj.seed if board_obj.seed is not None else 0
        with open(path, "w") as f:
            f.write(f"{board_obj.rows} {board_obj.cols} {board_obj.mines}\n")
            f.write(f"{int(elapsed)}\n")
            f.write(f"{int(seed_val)}\n")
            for row in board_obj.grid:
                f.write("".join(row) + "\n")
            for row in board_obj.revealed:
                f.write("".join("1" if x else "0" for x in row) + "\n")
            flags = ";".join(f"{r},{c}" for (r, c) in board_obj.flagged)
            f.write(flags + "\n")

    def read_slot(self, slot):
        path = self.slot_files[slot - 1]
        if not os.path.exists(path):
            return None
        with open(path, "r") as f:
            lines = [l.rstrip("\n") for l in f.readlines()]
        if len(lines) < 3:
            return None
        header = lines[0].split()
        if len(header) != 3 or not all(h.isdigit() for h in header):
            return None
        rows, cols, mines = map(int, header)
        if not lines[1].lstrip("-").isdigit():
            return None
        elapsed = int(lines[1])
        if not lines[2].lstrip("-").isdigit():
            return None
        seed = int(lines[2])
        if len(lines) < 3 + rows + rows:
            return None
        grid = [list(lines[3 + r]) for r in range(rows)]
        rev_start = 3 + rows
        revealed = [[c == "1" for c in lines[rev_start + r]] for r in range(rows)]
        flagged_line = lines[rev_start + rows] if len(lines) > rev_start + rows else ""
        flagged = set()
        if flagged_line:
            for pair in flagged_line.split(";"):
                if "," in pair:
                    pr, pc = pair.split(",")
                    if pr.lstrip("-").isdigit() and pc.lstrip("-").isdigit():
                        flagged.add((int(pr), int(pc)))
        return {
            "rows": rows,
            "cols": cols,
            "mines": mines,
            "grid": grid,
            "revealed": revealed,
            "flagged": flagged,
            "elapsed": elapsed,
            "seed": seed
        }

    def autosave_slot(self, board_obj, elapsed):
        for i in range(1, 4):
            if not self.slot_exists(i):
                self.write_slot(i, board_obj, elapsed)
                return i
        self.write_slot(1, board_obj, elapsed)
        return 1
