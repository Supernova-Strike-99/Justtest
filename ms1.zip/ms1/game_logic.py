# game_logic.py
import time
from tkinter import messagebox, Toplevel, Label, Button
from board import Board

class Game:
    """Game controller between Board, FileManager and UI."""
    def __init__(self, board_obj, file_manager, ui, post_game_callback):
        self.board = board_obj
        self.fm = file_manager
        self.ui = ui
        self.start_time = None
        self.game_over = False
        self.current_save_slot = None
        self.post_game_callback = post_game_callback

    def start(self, resume=False, elapsed_before=0):
        self.game_over = False
        self.ui.setup_grid(self.board.rows, self.board.cols, mines=self.board.mines)
        self.ui.bind_cell_handlers(self)

        if not resume:
            self.board.place_mines()
            self.start_time = time.time()
        else:
            self.start_time = time.time() - int(elapsed_before)

        self.ui.start_timer(self.get_elapsed)

        # render revealed cells and flags
        for r in range(self.board.rows):
            for c in range(self.board.cols):
                if self.board.revealed[r][c]:
                    self.ui.reveal_cell(r, c, self.board.grid[r][c])
        for (r, c) in sorted(self.board.flagged):
            self.ui.set_flag(r, c, True)

        # set counters initially
        self.ui.update_counters(len(self.board.flagged), self.board.mines)

        # add Save button
        self.ui.add_save_button(lambda: self._save_prompt())

    def get_elapsed(self):
        if self.start_time is None:
            return 0
        return int(time.time() - self.start_time)

    def on_click(self, r, c):
        if self.game_over:
            return
        if self.board.grid[r][c] == "M":
            self.board.revealed[r][c] = True
            self.ui.reveal_cell(r, c, "M")
            self._lose()
            return
        cells = self.board.reveal(r, c)
        for rr, cc, val in cells:
            self.ui.reveal_cell(rr, cc, val)
        if self.board.check_win():
            self._win()

    def on_flag(self, r, c):
        if self.game_over:
            return
        res = self.board.toggle_flag(r, c)
        if res is None:
            return
        self.ui.set_flag(r, c, res)
        # update counters each time a flag changes
        self.ui.update_counters(len(self.board.flagged), self.board.mines)
        if len(self.board.flagged) == self.board.mines and self.board.flagged == self.board.mine_set:
            self._win()

    def _win(self):
        self.game_over = True
        elapsed = self.get_elapsed()
        # save score automatically as a win and include seed
        self.fm.save_score(
            self.ui.get_player_name(),
            elapsed,
            self.board.rows,
            self.board.cols,
            self.board.mines,
            "win",
            seed=self.board.seed
        )
        messagebox.showinfo("Victory!", f"You cleared all mines in {elapsed} seconds!")
        if self.current_save_slot is not None:
            self.fm.delete_slot_file(self.current_save_slot)
        self.ui.close()
        if callable(self.post_game_callback):
            self.post_game_callback("win", elapsed)

    def _lose(self):
        self.game_over = True
        elapsed = self.get_elapsed()
        # reveal mines
        for (r, c, _) in self.board.reveal_all_mines():
            self.ui.reveal_mine(r, c)
        # save score as a loss (include seed)
        self.fm.save_score(
            self.ui.get_player_name(),
            elapsed,
            self.board.rows,
            self.board.cols,
            self.board.mines,
            "lose",
            seed=self.board.seed
        )
        messagebox.showinfo("Boom!", f"You hit a mine! Time: {elapsed}s")
        if self.current_save_slot is not None:
            self.fm.delete_slot_file(self.current_save_slot)
        self.ui.close()
        if callable(self.post_game_callback):
            self.post_game_callback("lose", elapsed)


    def _save_prompt(self):
        prompt = Toplevel()
        prompt.title("Save - Choose Slot")
        Label(prompt, text="Choose slot (1-3):").grid(row=0, column=0, columnspan=3, pady=6)

        def do_save(slot):
            if self.fm.slot_exists(slot):
                if not messagebox.askyesno("Overwrite?", f"Slot {slot} is occupied. Overwrite?"):
                    return
            elapsed = self.get_elapsed()
            if self.board.seed is None:
                self.board.seed = 0
            self.fm.write_slot(slot, self.board, elapsed)
            self.current_save_slot = slot
            messagebox.showinfo("Saved", f"Game saved to slot {slot}.")
            prompt.destroy()

        for i in range(1, 4):
            status = "Empty" if not self.fm.slot_exists(i) else "Occupied"
            Button(
                prompt,
                text=f"Slot {i}\n({status})",
                width=12,
                command=lambda s=i: do_save(s)
            ).grid(row=1, column=i-1, padx=6, pady=6)
