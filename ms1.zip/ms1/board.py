# board.py
import random

class Board:
    """Board holds grid, mines, revealed and flagged states and seed."""
    def __init__(self, rows, cols, mines, seed=None, grid=None, revealed=None, flagged=None):
        self.rows = rows
        self.cols = cols
        self.mines = mines
        self.seed = seed
        self.grid = grid
        self.revealed = revealed
        self.flagged = set(flagged) if flagged else set()
        self.mine_set = set()
        if self.grid is None or self.revealed is None:
            self._init_empty()

    def _init_empty(self):
        self.grid = [["0" for _ in range(self.cols)] for _ in range(self.rows)]
        self.revealed = [[False for _ in range(self.cols)] for _ in range(self.rows)]

    def place_mines(self, fixed_seed=None):
        """Place mines using a seed if provided or random otherwise."""
        if fixed_seed is not None:
            self.seed = int(fixed_seed)
            random.seed(self.seed)
        elif self.seed is not None:
            random.seed(int(self.seed))
        else:
            self.seed = random.randint(0, 10**9)
            random.seed(self.seed)

        self.grid = [["0" for _ in range(self.cols)] for _ in range(self.rows)]
        self.revealed = [[False for _ in range(self.cols)] for _ in range(self.rows)]
        self.flagged = set()
        total = self.rows * self.cols
        positions = random.sample(range(total), self.mines)
        self.mine_set = set()
        for idx in positions:
            r, c = divmod(idx, self.cols)
            self.grid[r][c] = "M"
            self.mine_set.add((r, c))

        # compute neighbor counts
        for r in range(self.rows):
            for c in range(self.cols):
                if self.grid[r][c] == "M":
                    continue
                cnt = 0
                for i in range(-1, 2):
                    for j in range(-1, 2):
                        nr, nc = r + i, c + j
                        if 0 <= nr < self.rows and 0 <= nc < self.cols and self.grid[nr][nc] == "M":
                            cnt += 1
                self.grid[r][c] = str(cnt)

        # return seed so callers can inspect / log it if needed
        return self.seed


        # compute neighbor counts
        for r in range(self.rows):
            for c in range(self.cols):
                if self.grid[r][c] == "M":
                    continue
                cnt = 0
                for i in range(-1, 2):
                    for j in range(-1, 2):
                        nr, nc = r + i, c + j
                        if 0 <= nr < self.rows and 0 <= nc < self.cols and self.grid[nr][nc] == "M":
                            cnt += 1
                self.grid[r][c] = str(cnt)

    def reveal(self, r, c):
        """Reveal cell; returns list of newly revealed (r,c,value)."""
        if self.revealed[r][c] or (r, c) in self.flagged:
            return []
        revealed_cells = []
        if self.grid[r][c] == "0":
            stack = [(r, c)]
            while stack:
                cr, cc = stack.pop()
                if self.revealed[cr][cc]:
                    continue
                self.revealed[cr][cc] = True
                revealed_cells.append((cr, cc, self.grid[cr][cc]))
                if self.grid[cr][cc] == "0":
                    for i in range(-1, 2):
                        for j in range(-1, 2):
                            nr, nc = cr + i, cc + j
                            if 0 <= nr < self.rows and 0 <= nc < self.cols and not self.revealed[nr][nc]:
                                stack.append((nr, nc))
        else:
            self.revealed[r][c] = True
            revealed_cells.append((r, c, self.grid[r][c]))
        return revealed_cells

    def toggle_flag(self, r, c):
        """Flag/unflag a cell. Return True if flagged, False if unflagged, None if already revealed."""
        if self.revealed[r][c]:
            return None
        if (r, c) in self.flagged:
            self.flagged.remove((r, c))
            return False
        else:
            self.flagged.add((r, c))
            return True

    def check_win(self):
        """Return True if all non-mine cells are revealed."""
        for r in range(self.rows):
            for c in range(self.cols):
                if self.grid[r][c] != "M" and not self.revealed[r][c]:
                    return False
        return True

    def reveal_all_mines(self):
        """Return list of all mines for UI reveal."""
        return [(r, c, "M") for (r, c) in self.mine_set]
