# main.py
import tkinter as tk
from tkinter import messagebox, Toplevel
from file_manager import FileManager
from board import Board
from game_logic import Game

# Defaults & presets
DEFAULT_ROWS, DEFAULT_COLS, DEFAULT_MINES = 9, 9, 15
EASY = (9, 9, 10)
NORMAL = (16, 16, 40)
HARD = (16, 30, 99)


class CanvasBoardUI:
    """
    Canvas-based Minesweeper UI. Renders a grid of perfectly square tiles and scales smoothly on resize/fullscreen.
    Minimal, robust implementation for clean fullscreen behavior.
    """
    PADDING = 6
    CELL_GAP = 2

    def __init__(self, root, player_name_callback):
        self.root = root
        self.player_name_callback = player_name_callback
        self.canvas = None
        self.rows = 0
        self.cols = 0
        self.mines = 0
        self.cell_size = 24
        self.offset_x = 0
        self.offset_y = 0
        self.rect_ids = {}
        self.text_ids = {}
        self.flag_ids = {}
        self.revealed = None
        self.grid_values = None
        self.flagged_set = set()
        self.timer_label = None
        self.counters_label = None
        self._controls_frame = None
        self._save_button = None
        self.timer_running = False

        self.color_map = {
            "1": "#0000FF", "2": "#008000", "3": "#FF0000", "4": "#000080",
            "5": "#800000", "6": "#008B8B", "7": "#000000", "8": "#808080"
        }

        self.root.bind("<Configure>", self._on_configure)

    def setup_grid(self, rows, cols, mines=None):
        # clear root grid widgets
        for w in list(self.root.grid_slaves()):
            w.grid_forget()

        self.rows = rows
        self.cols = cols
        self.mines = mines if mines is not None else 0

        # Header
        header = tk.Frame(self.root)
        header.grid(row=0, column=0, sticky="we", padx=6, pady=(6, 4))
        header.columnconfigure(0, weight=1)
        header.columnconfigure(1, weight=1)
        self.timer_label = tk.Label(header, text="Time: 0s", font=("Arial", 12, "bold"))
        self.timer_label.grid(row=0, column=0, sticky="w")
        self.counters_label = tk.Label(header, text=f"Flags: 0 / Mines: {self.mines}", font=("Arial", 10))
        self.counters_label.grid(row=0, column=1, sticky="e")

        # Canvas
        if self.canvas:
            self.canvas.destroy()
        self.canvas = tk.Canvas(self.root, bg="#dfeff0", highlightthickness=0)
        self.canvas.grid(row=1, column=0, sticky="nsew", padx=6, pady=6)

        # Controls row
        self._controls_frame = tk.Frame(self.root)
        self._controls_frame.grid(row=2, column=0, sticky="we", pady=(4, 8))

        # Root weights
        self.root.rowconfigure(0, weight=0)
        self.root.rowconfigure(1, weight=1)
        self.root.rowconfigure(2, weight=0)
        self.root.columnconfigure(0, weight=1)

        self.rect_ids.clear(); self.text_ids.clear(); self.flag_ids.clear()
        self.revealed = [[False for _ in range(self.cols)] for _ in range(self.rows)]
        self.grid_values = [["0" for _ in range(self.cols)] for _ in range(self.rows)]
        self.flagged_set = set()

        self._redraw_board()
        # bind clicks
        self.canvas.bind("<Button-1>", self._on_left_click)
        self.canvas.bind("<Button-3>", self._on_right_click)
        self.canvas.bind("<Control-Button-1>", self._on_right_click)

    def _on_configure(self, event):
        # throttle via after_idle
        self.root.after_idle(self._redraw_board)

    def _redraw_board(self):
        if not self.canvas or self.rows == 0 or self.cols == 0:
            return
        w = self.canvas.winfo_width() or 200
        h = self.canvas.winfo_height() or 200
        avail_w = max(20, w - 2 * self.PADDING)
        avail_h = max(20, h - 2 * self.PADDING)
        cell_w = (avail_w - (self.cols - 1) * self.CELL_GAP) // self.cols
        cell_h = (avail_h - (self.rows - 1) * self.CELL_GAP) // self.rows
        self.cell_size = max(12, min(cell_w, cell_h))

        board_w = self.cols * self.cell_size + (self.cols - 1) * self.CELL_GAP
        board_h = self.rows * self.cell_size + (self.rows - 1) * self.CELL_GAP
        self.offset_x = (w - board_w) // 2
        self.offset_y = (h - board_h) // 2

        self.canvas.delete("all")
        self.rect_ids.clear(); self.text_ids.clear(); self.flag_ids.clear()
        font_size = max(8, int(self.cell_size * 0.5))
        self._font = ("Arial", font_size, "bold")

        for r in range(self.rows):
            for c in range(self.cols):
                x1 = self.offset_x + c * (self.cell_size + self.CELL_GAP)
                y1 = self.offset_y + r * (self.cell_size + self.CELL_GAP)
                x2 = x1 + self.cell_size
                y2 = y1 + self.cell_size
                rect = self.canvas.create_rectangle(x1, y1, x2, y2, fill="#BFDDE1", outline="#8CAAB0", width=1)
                self.rect_ids[(r, c)] = rect
                if self.revealed[r][c]:
                    val = self.grid_values[r][c]
                    if val == "M":
                        tid = self.canvas.create_text((x1 + x2)//2, (y1 + y2)//2, text="M", font=self._font, fill="#000000")
                        self.text_ids[(r, c)] = tid
                        self.canvas.itemconfig(rect, fill="#FFBDBD")
                    elif val == "0":
                        self.canvas.itemconfig(rect, fill="#E6F7F7")
                    else:
                        fg = self.color_map.get(val, "black")
                        tid = self.canvas.create_text((x1 + x2)//2, (y1 + y2)//2, text=val, font=self._font, fill=fg)
                        self.text_ids[(r, c)] = tid
                        self.canvas.itemconfig(rect, fill="#E6F7F7")
                else:
                    if (r, c) in self.flagged_set:
                        f_id = self.canvas.create_text((x1 + x2)//2, (y1 + y2)//2, text="F", font=self._font, fill="red")
                        self.flag_ids[(r, c)] = f_id

    def bind_cell_handlers(self, game):
        self._game = game

    def _pos_to_cell(self, x, y):
        if self.rows == 0 or self.cols == 0:
            return None
        rx = x - self.offset_x
        ry = y - self.offset_y
        if rx < 0 or ry < 0:
            return None
        cell_plus_gap = self.cell_size + self.CELL_GAP
        c = rx // cell_plus_gap
        r = ry // cell_plus_gap
        if r < 0 or r >= self.rows or c < 0 or c >= self.cols:
            return None
        x0 = rx % cell_plus_gap
        y0 = ry % cell_plus_gap
        if x0 > self.cell_size or y0 > self.cell_size:
            return None
        return int(r), int(c)

    def _on_left_click(self, event):
        cell = self._pos_to_cell(event.x, event.y)
        if cell and hasattr(self, "_game"):
            r, c = cell
            self._game.on_click(r, c)

    def _on_right_click(self, event):
        cell = self._pos_to_cell(event.x, event.y)
        if cell and hasattr(self, "_game"):
            r, c = cell
            self._game.on_flag(r, c)

    # Methods called by Game
    def reveal_cell(self, r, c, value):
        self.revealed[r][c] = True
        self.grid_values[r][c] = value
        rect = self.rect_ids.get((r, c))
        if rect:
            x1, y1, x2, y2 = self.canvas.coords(rect)
            if (r, c) in self.flag_ids:
                self.canvas.delete(self.flag_ids[(r, c)]); del self.flag_ids[(r, c)]
            if (r, c) in self.text_ids:
                self.canvas.delete(self.text_ids[(r, c)]); del self.text_ids[(r, c)]
            if value == "M":
                tid = self.canvas.create_text((x1 + x2)//2, (y1 + y2)//2, text="M", font=self._font, fill="#000000")
                self.text_ids[(r, c)] = tid
                self.canvas.itemconfig(rect, fill="#FFBDBD")
            elif value == "0":
                self.canvas.itemconfig(rect, fill="#E6F7F7")
            else:
                fg = self.color_map.get(value, "black")
                tid = self.canvas.create_text((x1 + x2)//2, (y1 + y2)//2, text=value, font=self._font, fill=fg)
                self.text_ids[(r, c)] = tid
                self.canvas.itemconfig(rect, fill="#E6F7F7")

    def reveal_mine(self, r, c):
        self.revealed[r][c] = True
        self.grid_values[r][c] = "M"
        rect = self.rect_ids.get((r, c))
        if rect:
            if (r, c) in self.flag_ids:
                self.canvas.delete(self.flag_ids[(r, c)]); del self.flag_ids[(r, c)]
            if (r, c) in self.text_ids:
                self.canvas.delete(self.text_ids[(r, c)]); del self.text_ids[(r, c)]
            x1, y1, x2, y2 = self.canvas.coords(rect)
            tid = self.canvas.create_text((x1 + x2)//2, (y1 + y2)//2, text="M", font=self._font, fill="#000000")
            self.text_ids[(r, c)] = tid
            self.canvas.itemconfig(rect, fill="#FF7676")

    def set_flag(self, r, c, flagged):
        if flagged:
            if self.revealed[r][c]:
                return
            x1, y1, x2, y2 = self.canvas.coords(self.rect_ids[(r, c)])
            f_id = self.canvas.create_text((x1 + x2)//2, (y1 + y2)//2, text="F", font=self._font, fill="red")
            self.flag_ids[(r, c)] = f_id
            self.flagged_set.add((r, c))
        else:
            if (r, c) in self.flag_ids:
                self.canvas.delete(self.flag_ids[(r, c)])
                del self.flag_ids[(r, c)]
            self.flagged_set.discard((r, c))
        self.update_counters(len(self.flagged_set), self.mines)

    def update_counters(self, flagged_count, mines):
        remaining = mines - flagged_count
        if remaining < 0: remaining = 0
        self.counters_label.config(text=f"Flags: {flagged_count} / Mines: {mines} (Remaining: {remaining})")

    def start_timer(self, elapsed_fn):
        self.timer_running = True
        self._tick(elapsed_fn)

    def _tick(self, elapsed_fn):
        if not self.timer_running:
            return
        self.timer_label.config(text=f"Time: {elapsed_fn()}s")
        self.root.after(1000, lambda: self._tick(elapsed_fn))

    def close(self):
        try:
            self.timer_running = False
            self.root.destroy()
        except Exception:
            pass

    def get_player_name(self):
        return self.player_name_callback()

    def add_save_button(self, callback):
        if self._controls_frame is None:
            self._controls_frame = tk.Frame(self.root)
            self._controls_frame.grid()
        if self._save_button is None:
            self._save_button = tk.Button(self._controls_frame, text="Save", width=10, command=callback)
            self._save_button.pack(side="left", padx=6)
        else:
            self._save_button.config(command=callback)

    def add_fullscreen_button(self, callback):
        if self._controls_frame is None:
            self._controls_frame = tk.Frame(self.root)
            self._controls_frame.grid()
        btn = tk.Button(self._controls_frame, text="Toggle Fullscreen", width=16, command=callback)
        btn.pack(side="left", padx=6)


# Simple two-tab personal leaderboard shown from main menu
def show_personal_leaderboard(fm: FileManager, player_name: str):
    """
    Show a minimal leaderboard window with exactly two tabs: Wins and Losses.
    Under each tab show ONLY the player's most recent score for that category (if any).
    Also provide a button to view the full history for that player (optional).
    """
    name = (player_name or "").strip()
    if not name:
        messagebox.showerror("Missing name", "Enter your name in the menu to view your leaderboard entry.")
        return

    scores = fm.load_scores()  # list of dicts
    if not scores:
        messagebox.showinfo("Leaderboard", "No scores yet.")
        return

    # find most recent win and most recent loss for this player
    recent_win = None
    recent_loss = None
    # scan from end (newest -> oldest)
    for s in reversed(scores):
        if s.get("name") != name:
            continue
        res = s.get("result", "").lower()
        if res == "win" and recent_win is None:
            recent_win = s
        if res == "lose" and recent_loss is None:
            recent_loss = s
        if recent_win and recent_loss:
            break

    lb_win = Toplevel()
    lb_win.title(f"Leaderboard — {name}")
    lb_win.geometry("480x240")
    lb_win.minsize(380, 200)

    # Notebook with exactly two tabs
    from tkinter import ttk
    nb = ttk.Notebook(lb_win)
    nb.pack(fill="both", expand=True, padx=8, pady=8)

    frame_win = ttk.Frame(nb)
    frame_loss = ttk.Frame(nb)
    nb.add(frame_win, text="Wins")
    nb.add(frame_loss, text="Losses")

    def make_entry_frame(parent, entry):
        # show either the recent entry or a "No entries" label
        frm = tk.Frame(parent, padx=8, pady=8)
        frm.pack(fill="both", expand=True)
        if not entry:
            tk.Label(frm, text="No entries yet", font=("Arial", 11)).pack(pady=20)
            return
        # Show a compact row with Name | Time | Difficulty | Seed
        diff = f"[{entry.get('rows','?')}x{entry.get('cols','?')},{entry.get('mines','?')}]"
        seed = entry.get("seed", "?")
        txt = f"Name: {entry.get('name')}    Time: {entry.get('elapsed')}s    Difficulty: {diff}    Seed: {seed}"
        lbl = tk.Label(frm, text=txt, font=("Arial", 10), wraplength=440, justify="left")
        lbl.pack(anchor="w", pady=(12, 6))
        # a small button to view all history (if user wants)
        def view_history():
            # build and show simple history popup for this player
            hist = [x for x in scores if x.get("name") == name]
            if not hist:
                messagebox.showinfo("History", "No history for this player.")
                return
            hw = Toplevel(lb_win)
            hw.title(f"{name} — Full History")
            hw.geometry("620x320")
            from tkinter import ttk
            tree = ttk.Treeview(hw, columns=("idx", "result", "time", "difficulty", "seed"), show="headings")
            tree.heading("idx", text="#")
            tree.heading("result", text="Result")
            tree.heading("time", text="Time (s)")
            tree.heading("difficulty", text="Difficulty [rowsxcols,mines]")
            tree.heading("seed", text="Seed")
            tree.column("idx", width=40, anchor="center")
            tree.column("result", width=80, anchor="center")
            tree.column("time", width=90, anchor="center")
            tree.column("difficulty", width=280, anchor="w")
            tree.column("seed", width=120, anchor="center")
            tree.pack(fill="both", expand=True, padx=8, pady=8)
            for i, h in enumerate(hist, start=1):
                diff_h = f"[{h.get('rows','?')}x{h.get('cols','?')},{h.get('mines','?')}]"
                tree.insert("", "end", values=(i, h.get("result","?"), h.get("elapsed","?"), diff_h, h.get("seed","?")))

        btn = tk.Button(frm, text="View full history", command=view_history)
        btn.pack(anchor="w", pady=(6, 0))

    make_entry_frame(frame_win, recent_win)
    make_entry_frame(frame_loss, recent_loss)

    lb_win.transient()
    lb_win.grab_set()
    lb_win.focus_force()
    lb_win.update_idletasks()


# ---------- PostGameMenu (unchanged appearance) ----------
class PostGameMenu:
    def __init__(self, fm, player_name, rows, cols, mines, elapsed, result, same_start_cb, main_menu_cb):
        self.fm = fm
        self.player_name = player_name
        self.rows = rows
        self.cols = cols
        self.mines = mines
        self.elapsed = elapsed
        self.result = result
        self.same_start_cb = same_start_cb
        self.main_menu_cb = main_menu_cb

    def show(self):
        w = tk.Tk()
        w.title("Game Over")
        msg = f"You {'won' if self.result == 'win' else 'lost'}! Time: {self.elapsed}s"
        tk.Label(w, text=msg, font=("Arial", 12)).grid(row=0, column=0, columnspan=2, pady=(10, 8), padx=12)

        tk.Button(w, text="Play Again", width=18, command=lambda: self._play_again(w)).grid(row=1, column=0, columnspan=2, pady=6)
        tk.Button(w, text="View Leaderboard", width=18, command=lambda: self.fm.show_scores()).grid(row=2, column=0, columnspan=2, pady=6)
        tk.Button(w, text="Return to Main Menu", width=18, command=lambda: self._return_main(w)).grid(row=3, column=0, columnspan=2, pady=6)
        tk.Button(w, text="Exit", width=18, command=lambda: self._exit_all(w)).grid(row=4, column=0, columnspan=2, pady=(8, 12))

        w.update_idletasks()
        w.resizable(False, False)
        w.mainloop()

    def _play_again(self, parent):
        dlg = tk.Toplevel(parent)
        dlg.title("Play Again")
        dlg.transient(parent)
        dlg.grab_set()
        dlg.resizable(False, False)

        frm = tk.Frame(dlg, padx=12, pady=12)
        frm.pack(fill="both", expand=True)

        tk.Label(frm, text="Start with same settings or custom?", font=("Arial", 10)).pack(pady=(0, 8))

        btn_frame = tk.Frame(frm)
        btn_frame.pack()

        same_btn = tk.Button(btn_frame, text="Same settings", width=16, command=lambda: self._do_same(dlg, parent))
        same_btn.grid(row=0, column=0, padx=6, pady=6)

        custom_btn = tk.Button(btn_frame, text="Custom / Main Menu", width=16, command=lambda: self._do_custom(dlg, parent))
        custom_btn.grid(row=0, column=1, padx=6, pady=6)

        parent.update_idletasks()
        dlg.update_idletasks()
        pw = parent.winfo_width(); ph = parent.winfo_height()
        px = parent.winfo_rootx(); py = parent.winfo_rooty()
        dw = dlg.winfo_width(); dh = dlg.winfo_height()
        x = px + max(0, (pw - dw)//2)
        y = py + max(0, (ph - dh)//2)
        dlg.geometry(f"+{x}+{y}")

    def _do_same(self, dlg, parent):
        dlg.destroy()
        parent.destroy()
        self.same_start_cb(self.rows, self.cols, self.mines, self.player_name)

    def _do_custom(self, dlg, parent):
        dlg.destroy()
        parent.destroy()
        self.main_menu_cb()

    def _return_main(self, parent):
        parent.destroy()
        self.main_menu_cb()

    def _exit_all(self, parent):
        parent.destroy()
        import sys
        sys.exit(0)


# ---------- start_game (uses CanvasBoardUI) ----------
def start_game(rows, cols, mines, name, fm, slot_data=None):
    game_root = tk.Tk()
    game_root.title("Minesweeper")
    game_root.geometry("900x700")
    game_root.minsize(480, 360)
    game_root.resizable(True, True)

    is_fullscreen = {"value": False}
    def toggle_fullscreen(event=None):
        is_fullscreen["value"] = not is_fullscreen["value"]
        game_root.attributes("-fullscreen", is_fullscreen["value"])
    def exit_fullscreen(event=None):
        if is_fullscreen["value"]:
            is_fullscreen["value"] = False
            game_root.attributes("-fullscreen", False)

    game_root.bind("<F11>", toggle_fullscreen)
    game_root.bind("<Escape>", exit_fullscreen)

    ui = CanvasBoardUI(game_root, lambda: name)

    if slot_data is None:
        board = Board(rows, cols, mines)
    else:
        board = Board(
            slot_data["rows"],
            slot_data["cols"],
            slot_data["mines"],
            seed=slot_data.get("seed"),
            grid=slot_data.get("grid"),
            revealed=slot_data.get("revealed"),
            flagged=slot_data.get("flagged")
        )

    def post_game_cb(result, elapsed_seconds):
        def same_start(r, c, m, player_name):
            start_game(r, c, m, player_name, fm)
        def main_menu_cb():
            main_menu()
        pg = PostGameMenu(fm, name, board.rows, board.cols, board.mines, elapsed_seconds, result, same_start, main_menu_cb)
        pg.show()

    game = Game(board, fm, ui, post_game_callback=post_game_cb)

    def on_close():
        if not game.game_over:
            elapsed = game.get_elapsed()
            if getattr(game, "current_save_slot", None):
                slot_to_use = game.current_save_slot
                fm.write_slot(slot_to_use, board, elapsed)
                messagebox.showinfo("Auto-saved", f"Game auto-saved to slot {slot_to_use} (overwritten).")
            else:
                for i in range(1, 4):
                    if not fm.slot_exists(i):
                        fm.write_slot(i, board, elapsed)
                        messagebox.showinfo("Auto-saved", f"Game auto-saved to slot {i}.")
                        break
                else:
                    if messagebox.askyesno("Auto-save", "All save slots are occupied. Overwrite slot 1?"):
                        fm.write_slot(1, board, elapsed)
                        messagebox.showinfo("Auto-saved", "Game auto-saved to slot 1 (overwritten).")
                    else:
                        messagebox.showinfo("Auto-save", "Auto-save canceled; game not saved.")
        ui.close()

    game_root.protocol("WM_DELETE_WINDOW", on_close)

    # initialize UI
    ui.setup_grid(board.rows, board.cols, mines=board.mines)
    ui.bind_cell_handlers(game)
    ui.update_counters(len(board.flagged), board.mines)
    ui.add_save_button(lambda: game._save_prompt())
    ui.add_fullscreen_button(lambda: toggle_fullscreen())

    # load saved slot state or new board
    if slot_data is None:
        board.place_mines()
    else:
        ui.grid_values = slot_data.get("grid", ui.grid_values)
        ui.revealed = slot_data.get("revealed", ui.revealed)
        ui.flagged_set = set(slot_data.get("flagged", set()))

    # push reveals and flags from board to UI
    for r in range(board.rows):
        for c in range(board.cols):
            if board.revealed[r][c]:
                ui.reveal_cell(r, c, board.grid[r][c])
    for (r, c) in sorted(board.flagged):
        ui.set_flag(r, c, True)

    if slot_data is None:
        game.start(resume=False)
    else:
        game.start(resume=True, elapsed_before=slot_data.get("elapsed", 0))

    game_root.mainloop()


# ---------- main_menu ----------
def main_menu():
    fm = FileManager()
    win = tk.Tk()
    win.title("Minesweeper - Menu")
    win.geometry("360x480")
    win.minsize(320, 420)

    title = tk.Label(win, text="Minesweeper", font=("Arial", 16, "bold"))
    title.pack(pady=(12, 6))

    frm = tk.Frame(win)
    frm.pack(pady=6)

    tk.Label(frm, text="Name:", width=10, anchor="e").grid(row=0, column=0, padx=6, pady=6)
    entry_name = tk.Entry(frm, width=18)
    entry_name.grid(row=0, column=1, padx=6, pady=6)

    tk.Label(frm, text="Rows:", width=10, anchor="e").grid(row=1, column=0, padx=6, pady=6)
    entry_rows = tk.Entry(frm, width=18)
    entry_rows.grid(row=1, column=1, padx=6, pady=6)

    tk.Label(frm, text="Columns:", width=10, anchor="e").grid(row=2, column=0, padx=6, pady=6)
    entry_cols = tk.Entry(frm, width=18)
    entry_cols.grid(row=2, column=1, padx=6, pady=6)

    tk.Label(frm, text="Mines:", width=10, anchor="e").grid(row=3, column=0, padx=6, pady=6)
    entry_mines = tk.Entry(frm, width=18)
    entry_mines.grid(row=3, column=1, padx=6, pady=6)

    entry_rows.insert(0, str(DEFAULT_ROWS))
    entry_cols.insert(0, str(DEFAULT_COLS))
    entry_mines.insert(0, str(DEFAULT_MINES))

    def validate_name():
        n = entry_name.get().strip()
        if not n:
            messagebox.showerror("Missing name", "Please enter your name to continue.")
            return None
        return n

    def start_custom():
        name = validate_name()
        if name is None:
            return
        if not (entry_rows.get().isdigit() and entry_cols.get().isdigit() and entry_mines.get().isdigit()):
            messagebox.showerror("Error", "Enter valid numeric values.")
            return
        rows = int(entry_rows.get()); cols = int(entry_cols.get()); mines = int(entry_mines.get())
        if mines >= rows * cols:
            messagebox.showerror("Error", "Too many mines.")
            return
        win.destroy()
        start_game(rows, cols, mines, name, fm)

    def start_default():
        name = validate_name()
        if name is None:
            return
        win.destroy()
        start_game(DEFAULT_ROWS, DEFAULT_COLS, DEFAULT_MINES, name, fm)

    def start_preset(preset):
        name = validate_name()
        if name is None:
            return
        r, c, m = preset
        win.destroy()
        start_game(r, c, m, name, fm)

    def load_slot_prompt():
        name = validate_name()
        if name is None:
            return
        def do_load(slot):
            if not fm.slot_exists(slot):
                messagebox.showinfo("Load", f"Slot {slot} is empty.")
                return
            data = fm.read_slot(slot)
            if data is None:
                messagebox.showerror("Load", f"Slot {slot} appears corrupted.")
                return
            load_win.destroy()
            win.destroy()
            start_game(data["rows"], data["cols"], data["mines"], name, fm, slot_data=data)

        load_win = tk.Toplevel(win)
        load_win.title("Load Slot")
        tk.Label(load_win, text="Choose slot to load:").grid(row=0, column=0, columnspan=3, pady=6)
        for i in range(1, 4):
            status = "Empty" if not fm.slot_exists(i) else "Occupied"
            tk.Button(load_win, text=f"Slot {i}\n({status})", width=12, command=lambda s=i: do_load(s)).grid(row=1, column=i-1, padx=6, pady=6)

    btn_frame = tk.Frame(win)
    btn_frame.pack(pady=8)
    tk.Button(btn_frame, text="Start (custom)", width=16, command=start_custom).grid(row=0, column=0, padx=6, pady=4)
    tk.Button(btn_frame, text="Default (9x9,15)", width=16, command=start_default).grid(row=0, column=1, padx=6, pady=4)

    preset_frame = tk.Frame(win)
    preset_frame.pack(pady=6)
    tk.Label(preset_frame, text="Quick Presets:").grid(row=0, column=0, columnspan=3)
    tk.Button(preset_frame, text="Easy", width=10, command=lambda: start_preset(EASY)).grid(row=1, column=0, padx=6, pady=6)
    tk.Button(preset_frame, text="Normal", width=10, command=lambda: start_preset(NORMAL)).grid(row=1, column=1, padx=6, pady=6)
    tk.Button(preset_frame, text="Hard", width=10, command=lambda: start_preset(HARD)).grid(row=1, column=2, padx=6, pady=6)

    lower_frame = tk.Frame(win)
    lower_frame.pack(pady=8)
    tk.Button(lower_frame, text="Load", width=12, command=load_slot_prompt).grid(row=0, column=0, padx=6, pady=4)
    # Leaderboard now opens a minimal TWO-TAB view for the current player only
    tk.Button(lower_frame, text="Leaderboard", width=12,
              command=lambda: show_personal_leaderboard(fm, entry_name.get().strip())).grid(row=0, column=1, padx=6, pady=4)
    tk.Button(lower_frame, text="Clear Leaderboard", width=16, command=lambda: fm.clear_scores()).grid(row=0, column=2, padx=6, pady=4)

    bottom_frame = tk.Frame(win)
    bottom_frame.pack(pady=6)
    tk.Button(bottom_frame, text="Clear Slots", width=12, command=lambda: _clear_slots_confirm(win, fm)).grid(row=0, column=0, padx=6, pady=4)

    tk.Button(win, text="Exit", width=12, command=lambda: win.destroy()).pack(pady=(8, 12))

    win.mainloop()


def _clear_slots_confirm(parent, fm):
    if messagebox.askyesno("Clear save slots", "Delete all save slots? This cannot be undone."):
        fm.delete_all_slots()
        messagebox.showinfo("Done", "All save slots deleted.")


if __name__ == "__main__":
    main_menu()
